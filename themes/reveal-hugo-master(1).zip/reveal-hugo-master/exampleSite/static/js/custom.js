document.getElementById("customjs").addEventListener("click", function(){
    this.className += " customjs"
})