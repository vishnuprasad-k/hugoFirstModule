+++
+++

If more markdown files are present in the bundle, their contents will be added to the presentation.

---

Specify `weight` in the frontmatter if it's necessary to order them.

---

If you don't want them to be included, specify `layout = "list"` in the front matter instead of `layout = "bundle"`.

---

## THE END