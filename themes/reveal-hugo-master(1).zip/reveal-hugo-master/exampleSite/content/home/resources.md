+++
weight = 42
+++

# Resources

---

## Code and docs

- [reveal-hugo Github README](https://github.com/dzello/reveal-hugo)
- [Content for this presentation](https://github.com/dzello/reveal-hugo/tree/master/exampleSite)

---

## External resources

- [Reveal.js](https://revealjs.com/)
- [Hugo docs](https://gohugo.io/)
- [Hugo output format docs](https://gohugo.io/templates/output-formats/)

---

## Designed to...

- Deploy to [Netlify](https://netlify.com/)
- Edit with [Forestry](https://forestry.io/)

---

# 🙏

Contribute by opening issues and pull requests.

---

# Thanks!

---

# ↩️

#### [Start over](#)
