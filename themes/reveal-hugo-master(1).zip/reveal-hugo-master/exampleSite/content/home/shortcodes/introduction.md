+++
weight = 29
+++

# Shortcodes

---

Hugo's shortcodes are similar to functions or templates that extend what you can do with Markdown.

[Shortcode documentation](https://gohugo.io/content-management/shortcodes/)