+++
+++

{{< slide template="grey" >}}

Templates can be specified in `config.toml` as well, for reusability across multiple presentations.

```
[params.reveal_hugo.templates.grey]
background = "#424242"
transition = "convex"
```

---

## THE END