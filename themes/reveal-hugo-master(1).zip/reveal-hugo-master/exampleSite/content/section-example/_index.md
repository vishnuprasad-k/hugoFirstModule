+++
title = "Section presentation example"
outputs = ["Reveal"]
[reveal_hugo]
theme = "night"
margin = 0.2
+++

# Section Presentation

This is an example of a section presentation.

---

Section presentations are completely separate from the root presentation and each other.

---

Additional content files can be placed in the section and will be added to the presentation in the order of their weight.